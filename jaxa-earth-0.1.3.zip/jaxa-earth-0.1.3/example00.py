# Load module
from jaxa.earth import je

# Get all collections and bands
collections,bands = je.ImageCollectionList(ssl_verify=True)\
                      .filter_name()

# Select a collection,band index as you like
collection_index = 0
band_index       = 0

# Get collection id and band
collection = collections[collection_index]
band       = bands[collection_index][band_index]

# Print
print(f" - collection : {collection}, band : {band}")