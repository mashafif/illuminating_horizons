# JAXA Earth API for Python
JAXA Earth API for Python Package.

# Reference page
https://data.earth.jaxa.jp/api/python/index.html
